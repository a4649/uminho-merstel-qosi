# QoSI
Qualidade de Serviço em Redes IP / Internet

## How To Run the tool (Windows)

1. Install python - https://www.python.org/ftp/python/3.10.4/python-3.10.4-amd64.exe

2. Unzip folder QoSI-main.zip

3. Open the windows Command-Line and enter into unziped folder

```cd Downloads\QoSI-main```

3. Install requirements (pip and package modules):

```install.bat```

4. Run python script:
 
```python qosi.pyc```
