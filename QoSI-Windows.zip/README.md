# QoSI
Qualidade de Serviço em Redes IP / Internet

## Executar a ferramenta em PC Windows

1. Instalar manualmente o python - https://www.python.org/ftp/python/3.10.4/python-3.10.4-amd64.exe

2. Descompactar o ficheiro QoSI-Windows.zip

3. Abrir a linha de comandos do Windows e entrar na pasta descompactada

```cd Downloads\QoSI-Windows```

3. Instalar as dependencias (modulos pip):

```install.bat```

4. Executar o python script:
 
```python qosi.pyc```
